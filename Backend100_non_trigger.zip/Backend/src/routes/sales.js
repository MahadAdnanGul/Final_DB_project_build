const { Router } = require('express');
const router = Router();

const mysqlConnection = require('../database');

router.get('/', (req, res) => {
    console.log("oh no")
    mysqlConnection.query('select * from sales', (error, rows, fields) => {
        console.log("a")
        if (!error) {
            console.log(rows)
            res.json(rows);
        } else {
            console.log("c")
            console.log(error);
        }
    });
});

router.post('/', (req, res) => {
    console.log("heyyy");
    const { order_id,order_time,order_day,order_month,order_year,order_total } = req.body;
    console.log(req.body);
    mysqlConnection.query('insert into sales(order_id,order_time,order_day,order_month,order_year,order_total) values (?, ?,?,?,?,?)', [order_id,order_time,order_day,order_month,order_year,order_total], (error, rows, fields) => {
        if (!error) {
            res.json({ Status: "sales saved" })
        } else {
            console.log(error);
        }
    });
})

router.get('/:sales/:order_month/:order_year', (req, res) => {
    console.log("oh no")
    const { order_month,order_year } = req.params;
    mysqlConnection.query('select* from sales where order_month=? and order_year=?', [order_month,order_year], (error, rows, fields) => {
        console.log("a")
        if (!error) {
            console.log(rows)
            res.json(rows);
        } else {
            console.log("c")
            console.log(error);
        }
    });
});
module.exports = router;