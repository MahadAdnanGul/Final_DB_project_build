const { Router } = require('express');
const router = Router();

const mysqlConnection = require('../database');

router.put('/:customer_id', (req, res) => {
    console.log("help")
    const { customer_id, hash, status } = req.body;
    console.log(req.body);
    mysqlConnection.query('update cart set hash= ? ,status= ? where customer_id = ? and status = "NP";',
        [hash, status, customer_id], (error, rows, fields) => {
            if (!error) {
                res.json({
                    Status: 'Cart updated'

                });
            } else {
                console.log(error);
            }
        });
});





module.exports = router;