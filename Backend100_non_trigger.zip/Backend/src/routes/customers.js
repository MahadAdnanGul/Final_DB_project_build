const { Router } = require('express');
const router = Router();

const mysqlConnection = require('../database');

// router.get('/', (req, res) => {
//     res.status(200).json('you can now view the customers');
// });

router.get('/', (req, res) => {
    console.log("byeeee");
    mysqlConnection.query('select * from customer', (error, rows, fields) => {
        if(!error) {
            res.json(rows);
        } else {
            console.log(error);
        }
    });
});

//This function allows us concatenate 'id' to url => localhost:4000/id
router.get('/:customers/:customer_id', (req, res) => {
    const { customer_id } = req.params;
    mysqlConnection.query('select * from customer where customer_id = ?', [customer_id], (error, rows, fields) => {
        if(!error) {
            res.json(rows);
        } else {
            console.log(error);
        }
    })
});

router.post('/', (req, res) => {
    console.log("posttt");
    const { customer_id, customer_name, customer_number,customer_email,customer_address,customer_city, randomstr, hash } = req.body;
    console.log(req.body);
    mysqlConnection.query('insert into customer(customer_id, customer_name, customer_number, customer_email,customer_address,customer_city, randomstr, hash) values (?, ?, ?, ?, ?, ?,?,?)', [customer_id, customer_name, customer_number, customer_email,customer_address,customer_city, randomstr, hash], (error, rows, fields) => {
        if(!error) {
            res.json({Status : "Customer saved"})
        } else {
            res.json({Status: error})
            console.log(error);
        }
    });
})

router.put('/:customer_id', (req, res) => {
    const { customer_id, customer_name, customer_number, customer_email, customer_address, customer_city, randomstr, hash } = req.body;
    console.log(req.body);
    mysqlConnection.query('update customer set customer_name = ?, customer_number = ?, customer_email = ?,customer_address = ?,customer_city = ?, randomstr = ?, hash = ? where customer_id = ?;',
        [customer_name, customer_number, customer_email, customer_address, customer_city, randomstr, hash, customer_id], (error, rows, fields) => {
        if(!error){
            res.json({
                Status: 'Customer updated'
            });
        } else {
            console.log(error);
        }
    });
});

router.delete('/:customer_id', (req,res) => {
    const { customer_id } = req.params;
    mysqlConnection.query('delete from customer where customer_id = ?', [customer_id], (error, rows, fields) => {
        if(!error){
            res.json({
                Status: "User deleted"
            });
        } else {
            res.json({
                Status: error
            });
        }
    })
});

module.exports = router;

// [{
// 	"id":1,
//     "username": "Veterano23",
//     "name": "Jesus",
//     "lastname": "Hedo",
//     "mail": "hedo.jesus@gmail.com",
//     "randomstr": "dsDsfj=·",
//     "hash": "sdfjioi93448rfj7"
// },
// {
// 	"id":2,
//     "username": "Xavito95",
//     "name": "Xavi",
//     "lastname": "Castro",
//     "mail": "xc@gmail.com",
//     "randomstr": "gHf08vf^",
//     "hash": "1sr6p5ly´c,wzh6/"
// }]
