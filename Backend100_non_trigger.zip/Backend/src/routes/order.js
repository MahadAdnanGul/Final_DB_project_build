const { Router } = require('express');
const router = Router();

const mysqlConnection = require('../database');

router.post('/', (req, res) => {
    console.log("heyyy");
    const { customer_id, hash, time,day,month,year, order_status,order_total } = req.body;
    console.log(req.body);
    mysqlConnection.query('insert into orders(customer_id, hash, time, day, month,year,order_status,order_total) values (?, ?, ?, ?, ?,?,?,?)', [customer_id, hash, time,day,month,year, order_status, order_total], (error, rows, fields) => {
        if (!error) {
            res.json({ Status: "order saved" })
        } else {
            console.log(error);
        }
    });
});

router.get('/', (req, res) => {
    console.log("oh no")
    mysqlConnection.query('select * from orders', (error, rows, fields) => {
        console.log("a")
        if (!error) {
            console.log(rows)
            res.json(rows);
        } else {
            console.log("c")
            console.log(error);
        }
    });
});
router.put('/:order_id', (req, res) => {
    const { order_id, order_status } = req.body;
    console.log(req.body);
    mysqlConnection.query('update orders set order_status = ? where order_id = ?;',
        [order_status, order_id], (error, rows, fields) => {
            if (!error) {
                res.json({
                    Status: 'Order status updated'
                });
            } else {
                console.log(error);
            }
        });
});

module.exports = router;
